# AI-Driven Movie Recommendation System

This project delivers personalized movie recommendations using a hybrid AI-driven matchmaking system.

## Team Members
- Vimonika
- Vanisa

## Features
- Content-based filtering
- Collaborative filtering
- Hybrid recommendation logic
- Simple web interface using Flask

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run app: `python src/app.py`
