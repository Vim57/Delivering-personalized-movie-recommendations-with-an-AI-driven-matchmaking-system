from flask import Flask, request, jsonify
import pandas as pd
from model import build_content_model
from recommend import get_recommendations

app = Flask(__name__)
df = pd.read_csv("dataset/movies.csv")
sim_matrix = build_content_model(df)

@app.route("/recommend", methods=["GET"])
def recommend():
    title = request.args.get("title")
    if title not in df['title'].values:
        return jsonify({"error": "Movie not found"}), 404
    recs = get_recommendations(title, df, sim_matrix)
    return jsonify({"recommendations": recs})

if __name__ == "__main__":
    app.run(debug=True)
